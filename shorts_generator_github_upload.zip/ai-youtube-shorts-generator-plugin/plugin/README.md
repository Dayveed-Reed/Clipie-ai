# AI YouTube Shorts Generator Plugin

A ChatGPT/plugin-friendly HTTP wrapper around the included Shorts Generator.

## Run locally

From the repository root:

```bash
pip install -r plugin/requirements.txt
uvicorn plugin.app:app --host 0.0.0.0 --port 8000
```

Then open `/docs` to test it.

## API

- `GET /v1/health`
- `POST /v1/jobs` creates a generation job
- `GET /v1/jobs/{job_id}` polls a job
- `GET /v1/files/{filename}` serves locally rendered MP4 files

Set `SHORTS_PLUGIN_API_KEY` for a bearer/API-key protected deployment.

The long-running generation is asynchronous so a ChatGPT action does not need to keep an HTTP request open while Whisper/FFmpeg work runs.
