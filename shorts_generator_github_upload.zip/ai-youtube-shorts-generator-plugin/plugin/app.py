"""HTTP plugin/API wrapper for AI YouTube Shorts Generator."""
from __future__ import annotations

import os
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

from fastapi import FastAPI, Header, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field, field_validator

from shorts_generator import generate_shorts

APP_VERSION = "1.0.0"
PLUGIN_KEY = os.getenv("SHORTS_PLUGIN_API_KEY", "").strip()
OUTPUT_ROOT = Path(os.getenv("LOCAL_OUTPUT_DIR", "output")).resolve()
OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

app = FastAPI(
    title="AI YouTube Shorts Generator Plugin",
    version=APP_VERSION,
    description=(
        "Turn a YouTube video into ranked, vertical AI Shorts. "
        "The service wraps the open-source AI-Youtube-Shorts-Generator pipeline."
    ),
)

jobs: Dict[str, Dict[str, Any]] = {}
lock = threading.Lock()


class GenerateRequest(BaseModel):
    youtube_url: str = Field(..., description="YouTube URL or local file path/URL when using local mode")
    num_clips: int = Field(3, ge=1, le=20)
    aspect_ratio: str = Field("9:16", description="Output ratio, normally 9:16")
    download_format: str = Field("720", pattern="^(360|480|720|1080)$")
    language: Optional[str] = Field(None, description="ISO-639-1 language code, e.g. en")
    mode: str = Field("api", pattern="^(api|local)$")

    @field_validator("youtube_url")
    @classmethod
    def validate_url(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("youtube_url is required")
        if len(value) > 2048:
            raise ValueError("youtube_url is too long")
        return value


class JobResponse(BaseModel):
    job_id: str
    status: str
    created_at: str
    updated_at: str
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None


def _auth(authorization: Optional[str], x_api_key: Optional[str]) -> None:
    if not PLUGIN_KEY:
        return
    token = x_api_key or ""
    if authorization and authorization.lower().startswith("bearer "):
        token = authorization[7:].strip()
    if token != PLUGIN_KEY:
        raise HTTPException(status_code=401, detail="Invalid plugin API key")


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _worker(job_id: str, payload: GenerateRequest) -> None:
    with lock:
        jobs[job_id]["status"] = "processing"
        jobs[job_id]["updated_at"] = _now()
    try:
        result = generate_shorts(
            youtube_url=payload.youtube_url,
            num_clips=payload.num_clips,
            aspect_ratio=payload.aspect_ratio,
            download_format=payload.download_format,
            language=payload.language,
            mode=payload.mode,
        )
        # Do not expose arbitrary local filesystem paths through the public API.
        if payload.mode == "local":
            for short in result.get("shorts", []):
                path = short.get("clip_url")
                if path and not str(path).startswith("http"):
                    p = Path(path).resolve()
                    try:
                        short["clip_url"] = f"/v1/files/{p.name}"
                    except Exception:
                        short["clip_url"] = None
        with lock:
            jobs[job_id]["status"] = "completed"
            jobs[job_id]["result"] = result
            jobs[job_id]["updated_at"] = _now()
    except Exception as exc:
        with lock:
            jobs[job_id]["status"] = "failed"
            jobs[job_id]["error"] = f"{type(exc).__name__}: {exc}"
            jobs[job_id]["updated_at"] = _now()


@app.get("/v1/health")
def health() -> Dict[str, str]:
    return {"status": "ok", "version": APP_VERSION}


@app.post("/v1/jobs", response_model=JobResponse, status_code=202)
def create_job(
    request: GenerateRequest,
    authorization: Optional[str] = Header(default=None),
    x_api_key: Optional[str] = Header(default=None),
) -> JobResponse:
    _auth(authorization, x_api_key)
    job_id = uuid.uuid4().hex
    now = _now()
    with lock:
        jobs[job_id] = {"job_id": job_id, "status": "queued", "created_at": now, "updated_at": now}
    threading.Thread(target=_worker, args=(job_id, request), daemon=True).start()
    return JobResponse(**jobs[job_id])


@app.get("/v1/jobs/{job_id}", response_model=JobResponse)
def get_job(
    job_id: str,
    authorization: Optional[str] = Header(default=None),
    x_api_key: Optional[str] = Header(default=None),
) -> JobResponse:
    _auth(authorization, x_api_key)
    with lock:
        job = jobs.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return JobResponse(**job)


@app.get("/v1/files/{filename}")
def get_file(
    filename: str,
    authorization: Optional[str] = Header(default=None),
    x_api_key: Optional[str] = Header(default=None),
):
    _auth(authorization, x_api_key)
    # Basename-only prevents path traversal.
    safe = Path(filename).name
    path = (OUTPUT_ROOT / safe).resolve()
    if path.parent != OUTPUT_ROOT or not path.exists() or not path.is_file():
        raise HTTPException(status_code=404, detail="File not found")
    return FileResponse(path, media_type="video/mp4", filename=path.name)
